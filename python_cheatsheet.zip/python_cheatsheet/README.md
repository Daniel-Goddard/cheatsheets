# 🐍 Python Cheat Sheet

A single-page, dark-themed quick reference for Python — covering the core language plus the most-used data & ML libraries. Built as one self-contained HTML file, styled like a poster so it's easy to skim, print, or keep open in a tab while you work.

![style: dark](https://img.shields.io/badge/style-dark-0A0E17)
![type: reference](https://img.shields.io/badge/type-cheat--sheet-F2C14E)

## 📋 What's included

**Python Core**
- Basics, Control Flow, Functions & Classes
- Errors, Files & JSON
- Comprehensions, Async & Modules
- Typing & Debugging
- Operators (numeric, comparison, boolean)
- Time/Datetime, Statistics, Strings
- Collections — Set, Dict, List
- OS & File I/O
- Random & Math
- String / List / Set method examples (input → method → output)
- Handy one-liners & a mini password-generator project
- Data type comparison matrix (String / List / Tuple / Set / Dictionary)

**Libraries**
- Pandas
- NumPy
- Matplotlib
- Scikit-learn
- Seaborn
- TensorFlow / Keras
- PyTorch
- XGBoost

Each library section is color-coded and grouped into logical categories (creation, cleaning, training, plotting, evaluation, etc.), formatted as function → description tables.

## 🚀 Usage

This is a plain HTML file with no build step or dependencies.

1. Download `python_libraries_cheatsheet.html`
2. Open it in any browser — double-click it, or:
   ```bash
   open python_libraries_cheatsheet.html      # macOS
   start python_libraries_cheatsheet.html     # Windows
   xdg-open python_libraries_cheatsheet.html  # Linux
   ```
3. Or host it via GitHub Pages (see below) to share a live link.

## 🌐 Hosting on GitHub Pages

1. Push this repo to GitHub.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, set the source branch (e.g. `main`) and root folder.
4. Your cheat sheet will be live at:
   ```
   https://<your-username>.github.io/<repo-name>/python_libraries_cheatsheet.html
   ```

## 🛠️ Built with

- Plain HTML/CSS — no frameworks, no build tools
- [Space Grotesk](https://fonts.google.com/specimen/Space+Grotesk), [Inter](https://fonts.google.com/specimen/Inter), and [JetBrains Mono](https://fonts.google.com/specimen/JetBrains+Mono) via Google Fonts

## 📄 License

This project is licensed under the [MIT License](LICENSE) — feel free to use, modify, and share it, just keep the copyright notice.

## 🤝 Contributing

Spot an error or want to add a library? Pull requests are welcome — just keep the existing color/section structure consistent when adding new content.
